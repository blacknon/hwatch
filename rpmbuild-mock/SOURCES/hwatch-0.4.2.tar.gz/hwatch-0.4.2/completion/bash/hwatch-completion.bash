_hwatch() {
    local i cur prev opts cmd cmd_index skip_next
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    cmd=""
    opts=""
    cmd_index=-1
    skip_next=0

    for i in ${COMP_WORDS[@]}
    do
        case "${cmd},${i}" in
            ",$1")
                cmd="hwatch"
                ;;
            *)
                ;;
        esac
    done

    case "${cmd}" in
        hwatch)
            opts="-b -B -c -r -C -t -N -x -O -A -l -s -n -L -d -o -K -h -V --batch --beep --border --with-scrollbar --mouse --color --reverse --compress --no-title --line-number --no-help-banner --completion --exec --diff-output-only --aftercommand --logfile --shell --interval --precise --limit --tab-size --differences --output --keymap --help --version [command]..."
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 1 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --aftercommand)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -A)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --logfile)
                    local oldifs
                    if [ -n "${IFS+x}" ]; then
                        oldifs="$IFS"
                    fi
                    IFS=$'\n'
                    COMPREPLY=($(compgen -f "${cur}"))
                    if [ -n "${oldifs+x}" ]; then
                        IFS="$oldifs"
                    fi
                    if [[ "${BASH_VERSINFO[0]}" -ge 4 ]]; then
                        compopt -o filenames
                    fi
                    return 0
                    ;;
                -l)
                    local oldifs
                    if [ -n "${IFS+x}" ]; then
                        oldifs="$IFS"
                    fi
                    IFS=$'\n'
                    COMPREPLY=($(compgen -f "${cur}"))
                    if [ -n "${oldifs+x}" ]; then
                        IFS="$oldifs"
                    fi
                    if [[ "${BASH_VERSINFO[0]}" -ge 4 ]]; then
                        compopt -o filenames
                    fi
                    return 0
                    ;;
                --shell)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -s)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --interval)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --precise)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -n)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --limit)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -L)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tab-size)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --differences)
                    COMPREPLY=($(compgen -W "none watch line word" -- "${cur}"))
                    return 0
                    ;;
                -d)
                    COMPREPLY=($(compgen -W "none watch line word" -- "${cur}"))
                    return 0
                    ;;
                --output)
                    COMPREPLY=($(compgen -W "output stdout stderr" -- "${cur}"))
                    return 0
                    ;;
                -o)
                    COMPREPLY=($(compgen -W "output stdout stderr" -- "${cur}"))
                    return 0
                    ;;
                --keymap)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -K)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --completion)
                    COMPREPLY=($(compgen -W "bash fish zsh" -- "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac

            for ((i=1; i<${#COMP_WORDS[@]}; i++)); do
                if [[ ${skip_next} -eq 1 ]]; then
                    skip_next=0
                    continue
                fi

                case "${COMP_WORDS[i]}" in
                    --)
                        cmd_index=$((i + 1))
                        break
                        ;;
                    -A|--aftercommand|-l|--logfile|-s|--shell|-n|--interval|-L|--limit|--tab-size|-K|--keymap|--completion)
                        skip_next=1
                        ;;
                    -d|--differences)
                        case "${COMP_WORDS[i+1]}" in
                            none|watch|line|word)
                                skip_next=1
                                ;;
                        esac
                        ;;
                    -o|--output)
                        case "${COMP_WORDS[i+1]}" in
                            output|stdout|stderr)
                                skip_next=1
                                ;;
                        esac
                        ;;
                    -* )
                        ;;
                    *)
                        cmd_index=$i
                        break
                        ;;
                esac
            done

            if [[ ${cmd_index} -ge 1 && ${COMP_CWORD} -ge ${cmd_index} ]]; then
                if declare -F _command_offset >/dev/null 2>&1; then
                    _command_offset "${cmd_index}"
                    return 0
                fi
                if declare -F __start_command >/dev/null 2>&1; then
                    __start_command
                    return 0
                fi
                COMPREPLY=($(compgen -c -- "${cur}"))
                return 0
            fi

            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
    esac
}

if [[ "${BASH_VERSINFO[0]}" -eq 4 && "${BASH_VERSINFO[1]}" -ge 4 || "${BASH_VERSINFO[0]}" -gt 4 ]]; then
    complete -F _hwatch -o nosort -o bashdefault -o default hwatch
else
    complete -F _hwatch -o bashdefault -o default hwatch
fi
